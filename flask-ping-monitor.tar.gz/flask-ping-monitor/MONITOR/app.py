from flask import Flask, render_template, request, redirect, jsonify, send_file
import openpyxl
import os
from ping3 import ping
from datetime import datetime

app = Flask(__name__)

# Caminhos para os arquivos Excel
COMPUTADORES_FILE = "computadores.xlsx"
DEVICES_FILE = "devices.xlsx"
LOG_FILE = "device_logs.txt"  # Arquivo de log

# Verifica se os arquivos Excel existem e cria se não existirem
if not os.path.exists(COMPUTADORES_FILE):
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "Computadores"
    ws.append(["IP", "Usuário", "Tipo de Conexão", "Setor"])
    wb.save(COMPUTADORES_FILE)

if not os.path.exists(DEVICES_FILE):
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "Dispositivos"
    ws.append(["IP", "Usuário", "Tipo de Conexão", "Setor"])
    wb.save(DEVICES_FILE)

# Cache para dispositivos offline
offline_devices_cache = {}

# Função para carregar a planilha
def load_workbook(file_path):
    return openpyxl.load_workbook(file_path)

# Função para salvar a planilha
def save_workbook(wb, file_path):
    wb.save(file_path)

# Função para realizar o ping com múltiplas tentativas
def get_ping_latency(ip, retries=3):
    latencies = []
    for _ in range(retries):
        try:
            latency = ping(ip, timeout=1)  # Timeout de 1 segundo
            if latency is not None:
                latencies.append(latency * 1000)  # Converte para milissegundos
        except Exception as e:
            print(f"Erro ao pingar {ip}: {e}")
    if latencies:
        return round(sum(latencies) / len(latencies), 2)  # Retorna a média
    return None  # Dispositivo offline ou erro

# Função para registrar logs
def log_event(ip, event):
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    with open(LOG_FILE, "a") as log:
        log.write(f"{timestamp} - {ip} - {event}\n")

# Rota principal
@app.route("/")
def index():
    return render_template("index.html")

# Rota para adicionar dispositivo
@app.route("/add_device", methods=["POST"])
def add_device():
    ip = request.form.get("ip")
    username = request.form.get("username")
    connection_type = request.form.get("connection_type")
    sector = request.form.get("sector")

    wb = load_workbook(DEVICES_FILE)
    ws = wb.active
    ws.append([ip, username, connection_type, sector])
    save_workbook(wb, DEVICES_FILE)

    return redirect("/")

# Rota para editar dispositivo
@app.route("/edit_device", methods=["POST"])
def edit_device():
    old_ip = request.form.get("old_ip")
    new_ip = request.form.get("new_ip")
    new_username = request.form.get("new_username")
    new_connection_type = request.form.get("new_connection_type")
    new_sector = request.form.get("new_sector")

    wb = load_workbook(DEVICES_FILE)
    ws = wb.active

    for row in ws.iter_rows(min_row=2, max_col=4):
        if row[0].value == old_ip:
            row[0].value = new_ip
            row[1].value = new_username
            row[2].value = new_connection_type
            row[3].value = new_sector
            break

    save_workbook(wb, DEVICES_FILE)
    return redirect("/")

# Rota para deletar dispositivo
@app.route("/delete_device", methods=["POST"])
def delete_device():
    ip = request.form.get("ip")

    wb = load_workbook(DEVICES_FILE)
    ws = wb.active

    for row in ws.iter_rows(min_row=2, max_col=4):
        if row[0].value == ip:
            ws.delete_rows(row[0].row)
            break

    save_workbook(wb, DEVICES_FILE)
    return redirect("/")

# Rota para obter o status dos dispositivos
@app.route("/status")
def status():
    wb = load_workbook(DEVICES_FILE)
    ws = wb.active

    devices = []
    status_data = []
    offline_devices = []

    for row in ws.iter_rows(min_row=2, values_only=True):
        ip, username, connection_type, sector = row

        # Verifica se o dispositivo já está no cache
        if ip in offline_devices_cache:
            # Se estava offline, verifica se voltou a ficar online
            latency = get_ping_latency(ip)
            if latency is not None:
                # Dispositivo voltou a ficar online
                log_event(ip, "Voltou a ficar online")
                del offline_devices_cache[ip]  # Remove do cache de offline
                status = "online"
                packet_loss = 0
                message = "Conexão estável"
                offline_since = None
            else:
                # Continua offline
                status = "offline"
                latency = None
                packet_loss = 100
                message = "Dispositivo offline"
                offline_since = offline_devices_cache[ip]
        else:
            # Dispositivo não estava no cache (online ou nunca foi verificado)
            latency = get_ping_latency(ip)
            if latency is not None:
                status = "online"
                packet_loss = 0
                message = "Conexão estável"
                offline_since = None
            else:
                # Dispositivo ficou offline
                status = "offline"
                latency = None
                packet_loss = 100
                message = "Dispositivo offline"
                offline_since = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                offline_devices_cache[ip] = offline_since
                log_event(ip, "Ficou offline")

        devices.append({
            "ip": ip,
            "username": username,
            "connection_type": connection_type,
            "sector": sector
        })

        status_data.append({
            "ip": ip,
            "username": username,
            "connection_type": connection_type,
            "sector": sector,
            "status": status,
            "avg_latency": latency,
            "packet_loss": packet_loss,
            "message": message,
            "offline_since": offline_since
        })

        if status == "offline":
            offline_devices.append({
                "ip": ip,
                "username": username,
                "connection_type": connection_type,
                "sector": sector,
                "offline_since": offline_since
            })

    return jsonify({
        "devices": devices,
        "status_data": status_data,
        "offline_devices": offline_devices
    })

# Rota para salvar dispositivos offline em um arquivo .txt
@app.route("/save_offline_devices")
def save_offline_devices():
    wb = load_workbook(DEVICES_FILE)
    ws = wb.active

    offline_devices = []
    for row in ws.iter_rows(min_row=2, values_only=True):
        ip, username, connection_type, sector = row
        if ip in offline_devices_cache:
            offline_since = offline_devices_cache[ip]
            offline_devices.append(f"IP: {ip}, Usuário: {username}, Setor: {sector}, Tipo de Conexão: {connection_type}, Offline Desde: {offline_since}\n")

    # Salva os dispositivos offline em um arquivo .txt
    with open("offline_devices.txt", "w") as file:
        file.writelines(offline_devices)

    # Retorna o arquivo para download
    return send_file("offline_devices.txt", as_attachment=True)

if __name__ == "__main__":
    app.run(debug=True)